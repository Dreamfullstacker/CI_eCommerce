define([], function() {
    return undefined;
});