define(function() {
    return '&#8203;';
});