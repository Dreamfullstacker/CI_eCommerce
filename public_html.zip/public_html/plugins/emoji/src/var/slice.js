define([], function() {
    return [].slice;
});