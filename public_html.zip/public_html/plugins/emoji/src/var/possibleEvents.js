define(function() {
    return {};
});