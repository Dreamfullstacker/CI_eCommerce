define([], function() {
    return {};
});