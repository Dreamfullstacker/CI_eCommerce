define(function() {
    return "emojionearea";
});