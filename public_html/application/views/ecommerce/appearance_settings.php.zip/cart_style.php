<style type="text/css">	
	.yith-wcbsl-badge-wrapper {
	position : absolute;
	left : 10px;
	top : 10px;
	overflow : hidden;
	z-index: 99;
	}

	.yith-wcbsl-badge-content {
	height : 0px;
	background : #fff;
	border-radius: 10px;
	color : red;
	text-align : center;
	line-height : 20px;
	position : absolute;
	opacity: .8;
	/*font-family: arial;*/
	}

	.yith-wcbsl-badge-wrapper.yith-wcbsl-mini-badge {
	width : 40px;
	height : 25px;
	}

	.yith-wcbsl-badge-wrapper.yith-wcbsl-mini-badge .yith-wcbsl-badge-content {
	font-size : 11px;
	height : 20px;
	width : 40px;
	line-height : 20px;
	font-weight: bold;
	}
	.gallery.gallery-md{height: 100%;width: 100%;}
	.gallery.gallery-md .gallery-item{height: 91%;width: 100%;}
</style>